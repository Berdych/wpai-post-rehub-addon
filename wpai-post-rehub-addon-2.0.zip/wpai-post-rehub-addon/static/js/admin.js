(function($){$(function () {

	if($('.wpallimport-free-edition-notice') != undefined){
		$('.wpallimport-free-edition-notice').html('<p>If you need additional functions for Import or have any questions, please, write to our support <a href="http://themeforest.net/user/sizam#contact" target="_blank">through the contact form</a>. You must have actual license of Rehub to get our support.</p>');
	}

});})(jQuery);